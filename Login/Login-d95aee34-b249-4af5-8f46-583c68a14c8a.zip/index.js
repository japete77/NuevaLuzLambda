var AWS = require('aws-sdk'),
    uuid = require('uuid'),
	dynamodbClient = new AWS.DynamoDB.DocumentClient();
	
exports.handler = function(event, context, callback) {

    var sql = require("mssql");
    
    // config for your database
    const config = {
        user: process.env.user,
        password: process.env.password,
        server: process.env.server, 
        database: process.env.database,
        port: process.env.port
    };
    
    // connect to your database
    sql.connect(config, function (err) {

        if (err) callback(err)

        var request = new sql.Request();

        var query = `SELECT contrasena FROM US_usuarios WHERE id=${event.user}`

        // query to the database and get the records
        request.query(query, function (err, recordset) {

            sql.close();

            if (err) callback(err);
            
            var result = {
                Success: recordset.recordset.length > 0 && recordset.recordset[0].contrasena === event.password,
                Message: recordset.recordset.length == 0 || recordset.recordset[0].contrasena != event.password ? "Invalid username or password" : "",
                Session: recordset.recordset.length == 0 || recordset.recordset[0].contrasena != event.password ? "" : uuid.v1()
            };
            
            if (!result.Success) {
                callback(null, result);
            }
            
            var d = new Date();
            d.setSeconds(d.getSeconds() + Number(process.env.TTL_INCREASE_SECS));
            var ttl = Math.round(d.getTime() / 1000);
            
            var params = {
        		Item : {
        			"sessions" : result.Session,
        			"user": event.user,
        			"ttl" : ttl
        		},
        		TableName : process.env.TABLE_NAME
        	};
        	
        	dynamodbClient.put(params, function(err, data){
        		if (err) callback(err);
        		
                // send records as a response
                callback(null, result);
        	});
        });
    });
}
